<?php
session_start();



/*if( !empty($_SESSION['cart']) && isset($_POST['checkout']) ){

  //let user in


  //send user to home page
}else{

  header('location:index.php');
}

*/

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

    <script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="assets/css/style.css"/>


  </head>

  <body>

    <!--Navigation Bar-->
    <nav class="navbar navbar-expand-lg bg-warning py-3 fixed-top">
      <div class="container">
        <img class="logo" src="assets/imgs/logo.png"/>  
        <h2 class="navbar-brand" href="index.html">SF ORIGINAL</h2>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse nav-buttons" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">

            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="index.php">Home</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="shop.php">Shop</a>
            </li>
           
            <li class="nav-item">
              <a class="nav-link" href="blog.php">Blog</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="about.php">About Us</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact Us</a>
            </li>

            <li class="nav-item">
              <i class="fas fa-shopping-cart"></i>
            </li>

            <li class="nav-item">
              <i class="fas fa-user"></i>
            </li>

          </ul>
          <!--
          <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
          </form>-->
        </div>
      </div>
    </nav>


      <!--Payment-->
      <section class="my-5 py-5">
        <div class="container text-center mt-3 pt-5">
            <h2 class="mx-auto comtainer">Payment</h2>
            <hr class="mx-auto"></hr>
        </div>
        <div class="mx-auto cantainer text-center">
            <p><?php echo $_GET['order_status']; ?>
            <p>Total Payment: $<?php echo $_SESSION['total']; ?></p>
            <input class="btn btn-primary" type="submit" value="Pay Now" />
           

        </div>
      </section>







      <!--Footer-->
      <footer class="mt-5 py-5">
        <div class="row container mx-auto pt-5">
          <div class="footer-one col-lg-3 col-md-6 col-sm-12">
            <img class="logo" src="assets/imgs/logo1.png"/>
            <p class="pt-3">We provide the best products for the most affordable prices</p>
          </div>
          <div class="footer-one col-lg-3 col-md-6 col-sm-12">
            <h5 class="pb-2">Featured</h5>
            <ul class="text-uppercase">
              <li><a href="#">men</a></li>
              <li><a href="#">women</a></li>
              <li><a href="#">boys</a></li>
              <li><a href="#">girls</a></li>
              <li><a href="#">new arrivals</a></li>
              <li><a href="#">cloths</a></li>
            </ul>
          </div>

          <div class="footer-one col-lg-3 col-md-6 col-sm-12">
            <h5 class="pb-2">Contact Us</h5>
          
            <div>    
              <h6 class="text-uppercase">Address</h6>
              <p>Jogeshwari East Mumbai 400060</p>
            </div>
            <div>
              <h6 class="text-uppercase">Phone</h6>
              <p>+91 9224166366</p>
            </div>
            <div>
              <h6 class="text-uppercase">Email</h6>
              <p>rameshoym@gmail.com</p>
            </div>
            </div>

            <div class="footer-one col-lg-3 col-md-6 col-sm-12">
              <h5 class="pb-2">Instagram</h5>
              <div class="row">
                <img src="assets/imgs/Product/clothes1.jpg" class="img-fluid w-25 h-100 mb-2"/>
                <img src="assets/imgs/Product/featured1.jpg" class="img-fluid w-25 h-100 mb-2"/>
                <img src="assets/imgs/Product/shoes1.jpg" class="img-fluid w-25 h-100 mb-2"/>
                <img src="assets/imgs/Product/watch1.jpg" class="img-fluid w-25 h-100 mb-2"/>
                <img src="assets/imgs/Product/clothes4.jpg" class="img-fluid w-25 h-100 mb-2"/>
              </div>
            </div>
          </div>
        </div>


        <div class="copyright mt-5">
          <div class="row container mx-auto">
            <div class="footer-one col-lg-3 col-md-6 col-sm-12 mb-4">
              <img src="assets/imgs/payment.png"/>
            </div>
            <div class="footer-one col-lg-3 col-md-6 col-sm-12 mb-4 text-nowrap mb-2">
              <p>eCommerce @2022 All Right Reserved</p>
            </div>
            <div class="footer-one col-lg-3 col-md-6 col-sm-12">
              <a href="#"><i class="fab fa-facebook"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-whatsapp"></i></a>
            </div>
          </div>
        </div>
      </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

</body>
</html>