<?php


$conn = mysqli_connect("database-1.c0dryiqxbupt.us-east-1.rds.amazonaws.com","admin","Saudsyed82","project")
        or die("Couldn't connect to database");


?>
